import numpy as np
import time

def foo(x0,r,n):
    if n==0 :
        tmp=x0
    while 1:
        a = r * tmp - r * tmp * tmp
        n+=1
        tmp=a
        if  a<0.000001:
            print(a)
            return n

x0 = np.float32(0.9)
r=np.float32(4.0)
start=time.time()
print(foo(x0,r,0))