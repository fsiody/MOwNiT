import matplotlib.pyplot as plt
import numpy as np

def foo(x0,r,n):
    max=500
    if n==0 :
        xs.append(x0)
        ns.append(0)
        return foo(x0,r,n+1)
    if n<max:
        for i in range(len(ns)):
            if ns[i]==n-1:
                a = r * xs[i] - r * xs[i] * xs[i]
                ns.append(n)
                xs.append(a)
        return foo(x0, r, n + 1)
    else:
        return max
    return n

_, ax = plt.subplots()
x0 = np.float32(0.25)
r=np.float32(0.0)
step=np.float32(0.005)
while(r<=4.0):
    rs=[]
    xs=[]
    ns=[]
    foo(x0,r,0)
    for i in range(len(xs)):
        rs.append(r)
    ax.scatter(rs,xs,marker=".")
    r+=step

plt.show()